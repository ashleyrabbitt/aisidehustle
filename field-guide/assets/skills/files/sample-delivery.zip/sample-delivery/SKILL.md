---
name: sample-delivery
description: "Create a small, usable example and show exactly how the buyer would adapt it. Use for this task: Prepare a sample."
---

# Build a client-ready sample

Create a small, usable example and show exactly how the buyer would adapt it.

## Inputs

Buyer type, job they need done, one realistic fictional scenario, output format, verified constraints and details the buyer must fill in.

## Instructions

1. Choose one representative unit of the larger offer. Give the fictional client and scenario a visible sample label.
2. Draft the actual unit in the format the buyer will receive. Use bracketed placeholders for unknown facts and include only real claims supported by the brief.
3. Add a brief handoff explaining what to replace, where the item goes in the buyer's workflow, and how to check it before use.
4. Test the sample against the scenario. Return the item, the customization checklist and a one-sentence description of what the full service would deliver.

## Sample request

Create one sample reminder SMS for a fictional mobile dog groomer. It goes out the day before service. Include appointment time, reply instructions and a reschedule link. Stay under 145 characters before replacements. The business has no cancellation fee in this brief.

## Example result

Sample SMS: 'Hi [name], your dog’s grooming visit is tomorrow at [time]. Reply YES to confirm or reschedule here: [link].' Handoff: replace the three fields, test the link, and count the final characters after substitution.

## Acceptance check

A buyer can use the sample with only the listed replacements. The copy follows the requested format and includes no invented fees, promises or client results.
