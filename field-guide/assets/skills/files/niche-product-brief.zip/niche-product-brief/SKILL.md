---
name: niche-product-brief
description: "Keep the first version narrow enough to build and specific enough to test with prospective users. Use for this task: Plan a digital product."
---

# Niche digital product brief

Keep the first version narrow enough to build and specific enough to test with prospective users.

## Inputs

Buyer segment, repeated task, evidence from conversations or observation, available time, current workaround and an example of a finished result.

## Instructions

1. Describe the buyer at the moment the task occurs. Identify the trigger, current workaround and evidence of friction. Label each unsupported point as an assumption.
2. Choose the smallest artifact that completes one task. Specify its format, fields, one worked example and completion condition. List features to postpone.
3. Write a product promise tied to what the artifact actually produces. Treat any price as a test hypothesis unless a real transaction supports it.
4. Design a short use test with a realistic input, observable success measure, participant count and decision rule. Return a one-page brief with the first build task.

## Sample request

Create a two-hour product brief for independent craft fair sellers. Two sellers said they rebuild a packing list for each show. Test a printable with three other sellers. No one has paid. The goal is to finish a booth packing list in ten minutes.

## Example result

First version: a one-page checklist covering inventory, payment, display and weather, with blank rows for custom items. Show a completed example for a candle booth. Test three sellers planning a real show. Advance if two finish in ten minutes without help; pricing remains untested.

## Acceptance check

The brief identifies a specific buyer, one finished result, a buildable file and a pass/fail use test. It distinguishes observed demand signals from purchases.
