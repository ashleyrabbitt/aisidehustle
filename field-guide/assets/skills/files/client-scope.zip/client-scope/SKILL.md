---
name: client-scope
description: "Clarify what the client will receive, what they supply, and how both parties know the job is finished. Use for this task: Scope client work."
---

# One-page client scope

Clarify what the client will receive, what they supply, and how both parties know the job is finished.

## Inputs

Client request, audience, draft assets, delivery format, requested deadline, revision allowance, price if agreed and any outstanding dependencies.

## Instructions

1. Extract the client's desired result and the work they actually asked for. Separate confirmed commitments from assumptions. Ask the smallest question that would change price or timing.
2. Describe each deliverable as a countable item with a file format, owner and acceptance criterion. Set treatment for client-provided assets, an agreed revision round and out-of-scope additions.
3. Build the sequence around receipt of required inputs. If the deadline, price or reviewer is missing, leave a clearly marked field for confirmation.
4. Write a short client-ready scope ending with an approval question. Leave it as a draft for the freelancer to review.

## Sample request

Scope this sample request: a salon wants three appointment reminder emails in a Google Doc within five business days after receiving its existing booking policy. One revision is included. The salon sends the emails itself. Nobody has agreed a price.

## Example result

Deliver one Google Doc containing three emails, each with a subject line, body and editable booking link. The five-business-day clock starts when the salon supplies its booking policy. One consolidated revision is included. The salon handles sending. Fee: awaiting agreement.

## Acceptance check

A client can identify the deliverable, who supplies inputs, when timing starts, how to request a revision and which items still require agreement.
